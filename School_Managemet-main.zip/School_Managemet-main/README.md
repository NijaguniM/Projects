# School_Managemet
This is a software using JavaFx that is basically made for a school management. We can store profile of students, teachers and alumni of the school.
The students can see their result through the website. To monitor the process there is an admin who post result and every student can see this from their profile.
Besides, there is a group chat options for the students, teacher and also alumni.


